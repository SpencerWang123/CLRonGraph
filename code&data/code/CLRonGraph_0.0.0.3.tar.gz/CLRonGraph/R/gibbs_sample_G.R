#' generating R rounds of sample results of labels of the N observations
#'
#' @param reg_dt N*M principle components scores of the observations
#' @param label_initial N*1 vector of initialized label sequence
#' @param adj_mat N*N adjacency matrix indicating relation between N samples
#' @param lambda scalar indicating parameters used to construct a multinomial distribution
#' @param round_num R rounds-scalar indicating how many round the algorithm runs
#' @param seed random seed
#' @param method loss function used in the regression
#'
#' @return N*R label matrix indicating the sampling results of each round
#' @export
gibbs_sample_G=function (reg_dt, label_initial,adj_mat, lambda = 1, round_num = 110,
                         seed = 1, method = "ls",partition="Path",G_type="binary")
{
  set.seed(seed)
  label_list = NULL
  K = max(label_initial)
  N = nrow(reg_dt)
  temp_label = label_initial
  for (r in 1:round_num) {
    for (temp_mask_index in 1:N) {
      temp_estimation = estimation_fun(reg_dt = reg_dt,
                                       label = temp_label, mask_index = temp_mask_index,
                                       method = method, temp_K_seq = 1:K)
      temp_parameters=temp_estimation$parameters_mat
      temp_sd=sapply(temp_estimation$residuals_list,sd)
      temp_sd[which(temp_sd==0|is.na(temp_sd))]=mean(temp_sd,na.rm = T)#in case sd=0
      temp_multinomial = distribution_parameters(reg_dt = reg_dt,
                                                 estimated_parameters = temp_parameters,
                                                 sd_residuals=temp_sd,
                                                 mask_index = temp_mask_index,
                                                 lambda = lambda, method = method, K = K)
      if(G_type=="binary")
      {
      #修正采样处的连接情况
      temp_connect=adj_mat[,temp_mask_index]!=0
      #按照连接加权--会有问题，类似于邻居投票数*损失函数，大社团很容易吞并小社团
      candidate_label_table=table(temp_label[temp_connect])#筛选存在连接点的标签序列
      reserve_index=(1:K)%in%(names(candidate_label_table)[which(candidate_label_table>0)])#保留存在连接点的标签编号
      if(sum(reserve_index)<K)temp_multinomial[!reserve_index]=0
      }

      if(G_type=="weighted")
      {
        temp_connect=adj_mat[,temp_mask_index]
        parameter_adjust=tapply(temp_connect,factor(temp_label,levels = 1:K),sum)
        parameter_adjust[is.na(parameter_adjust)]=0
        temp_multinomial=as.numeric(temp_multinomial*parameter_adjust)
      }
      sample_label = as.numeric(rmultinom(1, 1, temp_multinomial))
      temp_label[temp_mask_index] = which(sample_label == 1)
    }
    label_list = c(label_list, temp_label)
  }
  label_mat = matrix(label_list, ncol = round_num)
  BIC_seq=apply(label_mat,2,BIC_fun,reg_dt=reg_dt,temp_K_seq=unique(label_initial),method=method)
  eBIC_seq=apply(label_mat,2,eBIC_fun,reg_dt=reg_dt,temp_K_seq=unique(label_initial),method=method,partition=partition,adj_mat=adj_mat)
  sample_res=c(label_mat=list(label_mat),BIC_seq=list(BIC_seq),eBIC_seq=list(eBIC_seq))
  return(sample_res)
}
