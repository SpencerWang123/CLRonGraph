#' integrated FMR algorithm for clustering regression
#'
#' @param reg_dt data.frame with first column named "y" as response variable and other columns are predictors
#' @param K_seq int. vector contains the numbers of clusters
#' @param true_label N*1 label vector contains ground truth labels
#' @param seed random seed
#'
#' @return list(assessment of the results,BIC_seq,eBIC_seq,coefficients_list,residuals_list)
#' assessment of the results: ARI and other assessment standards.
#' BIC_seq & eBIC_seq: sequence of BIC and eBIC with the same length as K_seq
#' coefficients_list: list consisting of the coefficients matrix estimated under each number of clusters with the same length as K_seq.
#' @export

GCLR_FMR=function(reg_dt,
                     K_seq,
                     true_label,
                     seed=1,
                  #best_model_criterion="BIC",
                  real_coefficients=NULL,
                  partition="Path",method="ls")
{## integrated algorithm
  set.seed(seed)
  N=nrow(reg_dt)
  #randomly shuffle the label of observation
  #reg_dt_ori=reg_dt;true_label_ori=true_label
  #shuffle_index=sample(N,N,replace = F)
  #reg_dt=reg_dt[shuffle_index,]
  #true_label=true_label[shuffle_index]
  assess_df=NULL
  BIC_seq=NULL
  eBIC_seq=NULL
  label_df=NULL
  coefficient_list=NULL
  residuals_list=NULL
  ## for different number of groups
  for (K in K_seq)
  {
    set.seed(seed)
    init_label=sample(1:K,N,replace = T)# random initialization
    reg_dt=reg_dt# data for regression
    #sample process
    sample_res=initFlexmix(y~.,data=reg_dt,k=K,model=FLXMRglm(),set.seed(seed))
    best_model=sample_res
    clu_res=as.numeric(best_model@cluster)
    # estimation
    final_label=clu_res
    estimation_temp=estimation_fun(reg_dt,final_label,mask_index=NULL,method=method,temp_K_seq=1:K)
    coef_temp=estimation_temp$parameters_mat
    residuals_temp=estimation_temp$residuals_list

    best_label=as.numeric(final_label)
    best_coefficient_mat=coef_temp
    best_cofficients=t(best_coefficient_mat[,best_label])
    if(is.null(real_coefficients)){real_coefficients=best_cofficients}
    MSE_coef=apply((best_cofficients-real_coefficients)^2,2,mean);names(MSE_coef)=c("Intercept",paste("X",1:(ncol(reg_dt)-1),sep = "."))
    # results assessment
    assess_res=c(ari(final_label,true_label),ri(final_label,true_label),nmi(final_label,true_label),MSE_coef)

    #BIC
    BIC_res=BIC_fun(reg_dt = reg_dt,label=final_label,temp_K_seq = 1:K,method = method)
    eBIC_res=eBIC_fun(reg_dt = reg_dt,label=final_label,temp_K_seq = 1:K,method = method,partition = partition)

    #saving results
    assess_df=c(assess_df,assess_res)
    BIC_seq=c(BIC_seq,BIC_res)
    eBIC_seq=c(eBIC_seq,eBIC_res)
    label_df=c(label_df,final_label)
    coefficient_list=c(coefficient_list,list(coef_temp))
    residuals_list=c(residuals_list,list(residuals_temp))
  }

  # reshape results
  ## assess_df
  assess_df=data.frame(t(matrix(assess_df,ncol = length(K_seq))));
  rownames(assess_df)=paste(method,K_seq,sep = "-")
  colnames(assess_df)=c("ARI","RI","NMI","Intercept","X.1","X.2")
  ## BIC_seq
  names(BIC_seq)=paste("cluster number=",K_seq)
  names(eBIC_seq)=paste("cluster number=",K_seq)
  ## label_df
  label_df=data.frame(matrix(label_df,ncol = length(K_seq)))
  rownames(label_df)=1:N
  colnames(label_df)=paste("group_result",K_seq,sep = "-")
  ## coefficient_list
  names(coefficient_list)=paste("cluster number=",K_seq)
  ## residuals_list
  names(residuals_list)=paste("cluster number=",K_seq)

  ##Best model
  #BIC
  best_model_index=which.min(BIC_seq)
  best_label=as.numeric(label_df[,best_model_index])#[order(shuffle_index)]
  best_coefficient_mat=coefficient_list[[best_model_index]]
  best_cofficients=t(best_coefficient_mat[,best_label])
  best_K=K_seq[best_model_index]
  assessment_best_model=c(assess_df[best_model_index,],best_K)
  best_model_BIC=list(assessment=assessment_best_model,K=best_K,label=best_label,coefficients=best_coefficient_mat)
  #eBIC
  best_model_index=which.min(eBIC_seq)
  best_label=as.numeric(label_df[,best_model_index])#[order(shuffle_index)]
  best_coefficient_mat=coefficient_list[[best_model_index]]
  best_cofficients=t(best_coefficient_mat[,best_label])
  best_K=K_seq[best_model_index]
  assessment_best_model=c(assess_df[best_model_index,],best_K)
  best_model_eBIC=list(assessment=assessment_best_model,K=best_K,label=best_label,coefficients=best_coefficient_mat)
  # outputs
  results_algorithm=list(best_model_BIC=best_model_BIC,best_model_eBIC=best_model_eBIC,assessment=assess_df,BIC=BIC_seq,eBIC=eBIC_seq,coefficients=coefficient_list,
                         labels=label_df,reg_dt=reg_dt,residuals_list=residuals_list)
  return(results_algorithm)
}
