#' Hypothesis test whether there are local regression structure on network
#'
#' @param reg_dt data.frame with first column named "y" as response variable and other columns are predictors
#' @param adj_mat adjacency matrix of observations
#' @param seed random seed
#' @export

local_structure_test=function(adj_mat,reg_dt,trials_time=1,subgraph_num=50,emperical_pdf_samples=100,alpha=0.05,group_scale=20,seed=1)
{
  set.seed(seed)
  # NULL distribution
  rsq_SG_mat=NULL;rsq_RSG_mat=NULL
  for(j in 1:emperical_pdf_samples)
  {
    reg_dt_random=reg_dt[sample(nrow(reg_dt),nrow(reg_dt)),]
    RSG_index=sapply((1:subgraph_num)*j,subgraph_sampling,adj_mat=adj_mat,graph_scale=group_scale)
    rsq_RSG=apply(RSG_index,2,estimation_SG,reg_dt=reg_dt_random)
    rsq_RSG_mat=c(rsq_RSG_mat,rsq_RSG)
  }

  #test trial
  for(t in 1:trials_time)
  {
    SG_index=sapply((1:subgraph_num)*t,subgraph_sampling,adj_mat=adj_mat,graph_scale=group_scale)
    rsq_SG=apply(SG_index,2,estimation_SG,reg_dt=reg_dt)
    rsq_SG_mat=c(rsq_SG_mat,rsq_SG)
  }
  rsq_SG_df=matrix(rsq_SG_mat, ncol = trials_time)
  rsq_RSG_df=matrix(rsq_RSG_mat,ncol = emperical_pdf_samples)
  rsq_stat=apply(rsq_RSG_df,2,mean)
  sq_stat=apply(rsq_SG_df,2,mean)
  thres_test=quantile(rsq_stat,1-alpha)
  return(list(results=c(sq_stat>thres_test),rsq_stat=rsq_stat,sq_stat=sq_stat))
}
subgraph_sampling=function(adj_mat,graph_scale,seed=1)
{
  set.seed(seed)
  m=graph_scale
  N=nrow(adj_mat)
  init_node=sample(N,1)
  node_connection=apply(adj_mat,1,sum)
  #
  temp_seq=init_node
  for(i in 1:(m-1))
  {
    temp_adj_mat=as.data.frame(adj_mat[,temp_seq])
    temp_node_connection=apply(temp_adj_mat,1,sum)
    temp_connection_dependence=(temp_node_connection/node_connection)[-temp_seq]
    candidate_list=(1:N)[-temp_seq]
    #
    temp_candidate_index=which(temp_connection_dependence==max(temp_connection_dependence))
    selected_candidate_index=temp_candidate_index[sample(length(temp_candidate_index),1)]
    #
    temp_seq=c(temp_seq,candidate_list[selected_candidate_index])
  }
  return(temp_seq)
}

random_sampling=function(adj_mat,graph_scale,seed=1)
{
  m=graph_scale
  set.seed(seed)
  N=nrow(adj_mat);temp_seq=sample(N,m)
  return(temp_seq)
}

estimation_SG=function(index_seq,reg_dt,target="r.squared")
{
  temp_reg_dt=reg_dt[index_seq,]
  temp_reg=lm(y~.,data = temp_reg_dt)
  temp_reg_summary=summary(temp_reg)
  if(target=="r.squared")temp_reg_summary$r.squared
}
