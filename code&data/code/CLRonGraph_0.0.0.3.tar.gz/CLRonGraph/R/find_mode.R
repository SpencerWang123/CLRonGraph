#' @export
#find mode
find_mode=function(x){return(names(sort(table(x),decreasing = T))[1])}#mode function
