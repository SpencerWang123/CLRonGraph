#' integrated gibbs sampling and estimation algorithm for clustering regression
#'
#' @param reg_dt data.frame with first column named "y" as response variable and other columns are predictors
#' @param adj_mat adjacency matrix of observations
#' @param K_seq int. vector contains the numbers of clusters
#' @param true_label N*1 label vector contains ground truth labels
#' @param rounds R rounds-scalar indicating how many round the algorithm runs
#' @param burning_period scalar indicating how many rounds of results are abandoned in the sampling process
#' @param method loss function used in the regression with candidates c("ls","hl","lad")
#' @param lambda scalar indicating the parameters used to construct a multinomial distribution
#' @param seed random seed
#'
#' @return list(assessment of the results,BIC_seq,coefficients_list,labels_trace,fpca,beta_trace,residuals_trace,residuals_list)
#' assessment of the results: ARI and other assessment standards.
#' BIC_seq: sequence of BIC with the same length as K_seq
#' coefficients_list: list consisting of the coefficients matrix estimated under each number of clusters with the same length as K_seq.
#' label trace: trace of the label sequence throughout sampling process
#' beta trace: each label sequence of the label trace generates one coefficient estimation
#' residual trace: each label sequence of the label trace generates one residuals sequence.
#' @export

GCLR=function(reg_dt,
              adj_mat=NULL,
              K_seq,
              true_label,
              rounds=110,
              burning_period=10,
              method="ls",
              lambda=1,
              partition="Path",
              #best_model_criterion="BIC",
              real_coefficients=NULL,
              seed=1,need_trace=F,greedy_refine=F,greedy_lambda=5,greedy_rounds=50,G_type="binary")
{## integrated algorithm
  set.seed(seed)
  N=nrow(reg_dt)
  #不给定 adjmat时候是常规的CLR
  if(is.null(adj_mat))
  {adj_mat=matrix(rep(1,N^2),nrow = N);
  adj_mat=adj_mat-diag(N);
  colnames(adj_mat)=1:N;rownames(adj_mat)=1:N
  }

  assess_df=NULL
  BIC_seq=NULL
  eBIC_seq=NULL
  label_df=NULL
  label_trace=NULL
  coefficient_list=NULL
  beta_trace=NULL
  residuals_trace=NULL
  residuals_list=NULL
  ## for different number of groups
  for (K in K_seq)
  {
    init_label=sample(1:K,N,replace = T)# random initialization
    reg_dt=reg_dt# data for regression
    #sample process
    sample_res=gibbs_sample_G(reg_dt = reg_dt,label_initial = init_label,adj_mat = adj_mat,round_num = rounds,method = method,lambda = lambda,seed = seed,partition=partition,G_type=G_type)$label_mat
    sample_res_plot=sample_res
    print(K)
    #label_trace
    label_trace=c(label_trace,list(sample_res_plot))
    #estimation_trace
    if(need_trace)
    {
      estimation_trace=apply(sample_res_plot,2,estimation_fun,reg_dt=reg_dt,temp_K_seq=1:K,mask_index=NULL)
      #beta trace
      beta_trace_mat=vector("list",rounds)
      for (i in 1:ncol(sample_res_plot))
      {beta_trace_mat[[i]]=estimation_trace[[i]][[1]]}
      names(beta_trace_mat)=paste("round",1:rounds)
      beta_trace=c(beta_trace,list(beta_trace_mat))

      #residuals trace
      residuals_trace_mat=vector("list",rounds)
      for (i in 1:ncol(sample_res_plot))
      {residuals_trace_mat[[i]]=estimation_trace[[i]][[2]]}
      names(residuals_trace_mat)=paste("round",1:rounds)
      residuals_trace=c(residuals_trace,list(residuals_trace_mat))
    }else{
      beta_trace=c(beta_trace,list("no record"))
      residuals_trace=c(residuals_trace,list("no record"))
    }


    #burning period
    preserved_rounds=burning_period:ncol(sample_res)
    mode_group=as.numeric(apply(sample_res[,preserved_rounds],1,find_mode))#Mode function definition


    if(!greedy_refine){final_label=mode_group}else
    {
      sample_res_refine=gibbs_sample_G(reg_dt = reg_dt,label_initial = mode_group,adj_mat = adj_mat,round_num = greedy_rounds,method = method,lambda = greedy_lambda,seed = seed,G_type=G_type)$label_mat
      mode_group_refine=apply(sample_res_refine,1,find_mode)
      final_label=mode_group_refine
    }
    # estimation
    estimation_temp=estimation_fun(reg_dt,final_label,mask_index=NULL,method=method,temp_K_seq=1:K)
    coef_temp=estimation_temp$parameters_mat
    residuals_temp=estimation_temp$residuals_list

    #最终标签结果判定-贪婪搜索-0-暂时不用，选择采用mode 结果直接使用
    estimated_y=as.matrix(cbind(rep(1,N),reg_dt[,2:ncol(reg_dt)]))%*%coef_temp
    abs_error=abs(estimated_y-reg_dt[,1])


    best_label=as.numeric(final_label)
    best_coefficient_mat=coef_temp
    best_cofficients=t(best_coefficient_mat[,best_label])
    if(is.null(real_coefficients)){real_coefficients=best_cofficients}
    MSE_coef=apply((best_cofficients-real_coefficients)^2,2,mean);names(MSE_coef)=c("Intercept",paste("X",1:(ncol(reg_dt)-1),sep = "."))
    # results assessment
    assess_res=c(ari(final_label,true_label),ri(final_label,true_label),nmi(final_label,true_label),MSE_coef)

    #BIC
    BIC_res=BIC_fun(reg_dt = reg_dt,label=final_label,temp_K_seq = 1:K,method = method)
    eBIC_res=eBIC_fun(reg_dt = reg_dt,adj_mat=adj_mat,label=final_label,temp_K_seq = 1:K,method = method,partition = partition)

    #saving results
    assess_df=c(assess_df,assess_res)
    BIC_seq=c(BIC_seq,BIC_res)
    eBIC_seq=c(eBIC_seq,eBIC_res)
    label_df=c(label_df,final_label)
    coefficient_list=c(coefficient_list,list(coef_temp))
    residuals_list=c(residuals_list,list(residuals_temp))
  }

  # reshape results
  ## assess_df
  assess_df=data.frame(t(matrix(assess_df,ncol = length(K_seq))));
  rownames(assess_df)=paste(method,K_seq,sep = "-")
  colnames(assess_df)=c("ARI","RI","NMI","Intercept","X.1","X.2")
  ## BIC_seq
  names(BIC_seq)=paste("cluster number=",K_seq)
  names(eBIC_seq)=paste("cluster number=",K_seq)
  ## label_df
  label_df=data.frame(matrix(label_df,ncol = length(K_seq)))
  rownames(label_df)=1:N
  colnames(label_df)=paste("group_result",K_seq,sep = "-")
  ## coefficient_list
  names(coefficient_list)=paste("cluster number=",K_seq)
  ## residuals_list
  names(residuals_list)=paste("cluster number=",K_seq)
  ##beta trace
  names(beta_trace)=paste("cluster number=",K_seq)
  ##residuals trace
  names(residuals_trace)=paste("cluster number=",K_seq)
  ##label_trace
  names(label_trace)=paste("cluster number=",K_seq)
  ##Best model
  #BIC
  best_model_index=which.min(BIC_seq)
  best_label=as.numeric(label_df[,best_model_index])
  best_coefficient_mat=coefficient_list[[best_model_index]]
  best_cofficients=t(best_coefficient_mat[,best_label])
  best_K=K_seq[best_model_index]
  assessment_best_model=c(assess_df[best_model_index,],best_K)
  best_model_BIC=list(assessment=assessment_best_model,K=best_K,label=best_label,coefficients=best_coefficient_mat)
  #eBIC
  best_model_index=which.min(eBIC_seq)
  best_label=as.numeric(label_df[,best_model_index])
  best_coefficient_mat=coefficient_list[[best_model_index]]
  best_cofficients=t(best_coefficient_mat[,best_label])
  best_K=K_seq[best_model_index]
  assessment_best_model=c(assess_df[best_model_index,],best_K)
  best_model_eBIC=list(assessment=assessment_best_model,K=best_K,label=best_label,coefficients=best_coefficient_mat)
  # outputs
  results_algorithm=list(best_model_BIC=best_model_BIC,best_model_eBIC=best_model_eBIC,assessment=assess_df,BIC=BIC_seq,eBIC=eBIC_seq,coefficients=coefficient_list,
                         labels=label_df,label_trace=label_trace,reg_dt=reg_dt,
                         beta_trace=beta_trace,residuals_trace=residuals_trace,
                         residuals_list=residuals_list)
  return(results_algorithm)
}
